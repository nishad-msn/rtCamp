<?php 

/* Template Name: Homepage Template */ 
 

/**
 * The template for displaying all pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package rtcamp
 */

get_header();
?>

<div id="primary" class="content-area">	<!-- #primary -->
	<main id="main" class="site-main">	<!-- Main Area -->

		<div class="hp_top_slider_parent">	<!-- Slider Parent Div -->

			<?php

			if ( get_field('theme_top_page_slider_images', 'option') ) {	// If has Slider Images 
				
				?>

				<?php

				if ( get_field('theme_top_page_content', 'option') ) {
					echo '<div class="hp_top_slider_div owl-carousel owl-theme">' ;	//Slider div Normal
				}

				else {
					echo '<div class="hp_top_slider_div owl-carousel owl-theme fullwidth">' ;	//Slider div full width
				}

				?>

					<?php

						$image_urls = get_field('theme_top_page_slider_images', 'option');

						foreach( $image_urls as $image_url ): 

							?>

							<div class="hp_top_slider_single_item"> <!-- Single Item -->
								<img class="hp_top_slider_single_img" src="<?php echo $image_url  ; ?>">
							</div>	<!-- Single Item -->

							<?php
						
						endforeach; 

					?>
					
				</div>	<!-- Slider Div -->

				<?php

			}	// If has Slider Images 
			

			?>


			
			

			<?php

			if ( get_field('theme_top_page_content', 'option') ) {	// if has Page Info
				
				$pagey_id = get_field('theme_top_page_content', 'option') ;

				?>

				<?php

				if ( get_field('theme_top_page_slider_images', 'option') ) {
					echo '<div class="hp_top_page_info_div">' ;	//Page info div Normal
				}

				else {
					echo '<div class="hp_top_page_info_div fullwidth">' ;	//Page info div full width
				}

				?>
				
					<h3 class="hp_para_title"> <?php echo get_the_title( $pagey_id )  ; ?> </h3>

					<div class="divider_10"></div>

					<div class="hp_para_content">
						<?php 
							$post = get_post($pagey_id); 
							$content = apply_filters('the_content', $post->post_content); 
							//echo $content;  
							grab_firsty_img();

							if ( grab_firsty_img() != "empty" ) {
								echo '<img src="' . grab_firsty_img() . '">' ;
							}

							echo wp_trim_words( $content , 60);

						?>
					</div>

					<a href="<?php echo get_the_permalink( $pagey_id  ) ; ?>" class="hp_top_page_info_readmore">Read More</a>

				</div>	<!-- Page info div -->

				<?php

			}	// if has Page Info

			?>

			

			<div class="clearfix"></div>


		</div>	<!-- Slider Parent Div -->


		<div class="hruler margined"></div>


		

		<?php

		if ( get_field('theme_youtube_slider_links' , 'option' ) ) {

			?>

			<div class="container">	<!-- Container -->

				<div class="row">	<!-- Row -->

					<?php


					echo '<div class="youtube_slider_parent owl-carousel owl-theme">' ;	// Youtube Slider 
					
					$links = get_field('theme_youtube_slider_links' , 'option' ) ;
					$links = preg_split("/\r\n|\n|\r/", $links) ;

					foreach( $links as $link ): 

						?>

						<a class="youtube_slider_single_item thickbox" href="https://www.youtube.com/embed/<?php echo $link ; ?>?rel=0?KeepThis=true&TB_iframe=true&height=400&width=600">	<!-- youtube single item -->
						
							<img class="youtube_slider_single_item_img" src="<?php echo 'https://img.youtube.com/vi/' . $link . '/hqdefault.jpg' ; ?>">
							<img class="youtube_slider_single_item_icon" src="<?php echo get_stylesheet_directory_uri() . '/lib/play.png' ; ?>">

						</a>	<!-- youtube single item -->

						<?php
					
					endforeach; 

					echo '</div>' ;	// Youtube Slider 

				?>

				</div>	<!-- Row -->

			</div>	<!-- Container -->

			<div class="hruler margined"></div>

			<?php

		}

		?>
				
			



 

		<div class="hp_middle_columns_parenter"> <!-- Middle Section Div -->
			
			<div class="container">	<!-- Container -->
				
				<div class="row">	<!-- Row -->
					
					<div class="col-sm-8">	<!-- col -->

						<?php 	// Custom Post Type Thumbnails

							$args = array(  
 									'post_type' => 'exhibition',
 									'post_status' => 'publish',
 									'posts_per_page' => 8, 
 									'order' => 'DESC',
 									'orderby' => 'date', 
 									) ;

 							$new_query = new WP_Query( $args ); 

 							?>

 							<h3 class="colored_title">Glimpses of Exhibition</h3>

 							<div class="row">	<!-- Row -->

 							<?php
 							    
 							while ( $new_query->have_posts() ) : 

 								$new_query->the_post(); 

 								?>

 								<div class="col-md-3 col-xs-6">
								
									<a class="hp_glimpses_single_box" href="<?php the_permalink() ; ?>">
										<img src="<?php echo get_the_post_thumbnail_url(get_the_ID(),'medium') ; ?>">
									</a>

									<a href="<?php the_permalink() ; ?>" class="hp_glimpses_single_linker"><?php the_title() ; ?></a>

								</div>

								<?php

 							endwhile;

 							?>

 							</div>	<!-- Row -->

							<div class="hruler"></div>

							<?php

 							wp_reset_postdata(); 

   						?>	<!-- Custom Post Type Thumbnails -->
						


						<div class="row">	<!-- Row -->

							<div class="col-sm-5">	<!-- col -->

								<h3 class="colored_title">Latest Tweets</h3>

								<?php echo do_shortcode('[custom-twitter-feeds]') ; ?>
								
							</div>	<!-- col -->


							<div class="col-sm-7">	<!-- col -->

								<h3 class="colored_title">Follow us on FaceBook</h3>

								<div class="fb-page" data-href="https://www.facebook.com/rushmovie" data-tabs="" data-width="" data-height="250" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true"><blockquote cite="https://www.facebook.com/rushmovie" class="fb-xfbml-parse-ignore"><a href="https://www.facebook.com/rushmovie">RUSH</a></blockquote></div>
								
							</div>	<!-- col -->
							
						</div>	<!-- Row -->



					</div>	<!-- col -->



					<div class="col-sm-4">	<!-- col -->


						<?php 	// Sidebar Widget Area
 
						if ( is_active_sidebar( 'rtcamp-homepage-sidebar' ) ) :

							echo '<div class="rtcamp_custom_widget_area widget-area" role="complementary">' ;
						    
						    	dynamic_sidebar( 'rtcamp-homepage-sidebar' ); 

						    echo '</div>' ;
						     
						endif; 

						?>	<!-- Sidebar Widget Area -->

					</div>	<!-- col -->

				</div>	<!-- Row -->

			</div>	<!-- Container -->


			<?php 	// Custom Post Type Thumbnails

			$args = array(  
 					'post_type' => 'partner',
 					'post_status' => 'publish',
 					'posts_per_page' => 8, 
 					'order' => 'ASC',
 					'orderby' => 'date', 
 					) ;

 			$new_query = new WP_Query( $args ); 

 			?>

 			<div class="container">	<!-- Container -->
			
				<h3 class="colored_title">Our Partners</h3>

				<div class="row">	<!-- Row -->
				
				<div class="youtube_slider_parent owl-carousel owl-theme">	<!-- Client Slider -->


				<?php

 				    
 				while ( $new_query->have_posts() ) : 

 					$new_query->the_post(); 

 					?>

 					<a class="clients_slider_single_item">	<!-- youtube single item -->
						
						<img class="clients_slider_single_item_img" src="<?php echo get_the_post_thumbnail_url(get_the_ID(),'medium') ; ?>">

					</a>	<!-- youtube single item --> 

					<?php 

 				endwhile;

 			?>

 				</div>	<!-- client Slider -->

			</div>	<!-- Row -->

			<div class="hruler margined"></div>

			</div>	<!-- Container -->

			<?php

 				wp_reset_postdata(); 

   			?>	<!-- Custom Post Type Thumbnails -->



		</div>	<!-- Middle Section Div -->
		

	</main>	<!-- Main Area -->
</div>	<!-- #primary -->	



<!-- Jquery CDN -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<!-- Jquery CDN -->


<!-- Owl carousel files -->

<script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js" integrity="sha256-pTxD+DSzIwmwhOqTFN+DB+nHjO4iAsbgfyFq5K5bcE0=" crossorigin="anonymous"></script>

<!-- Owl carousel files -->


<!-- Thickbox Files -->

<script type="text/javascript" src="<?php echo get_stylesheet_directory_uri() . '/lib/thickbox/thickbox-compressed.js' ?>"></script>

<!-- Thickbox Files -->

 


<script type="text/javascript">
	
	$(document).ready(function(){
	
		
		// Main Slider Owl Carousel Init

		$('.hp_top_slider_div.owl-carousel').owlCarousel({
		    loop:true,
		    items:1,
		    nav: false,
		    dots: true,
		    autoplay:true,
		    autoplayTimeout: 8000,
		    autoplayHoverPause:true,
		})



		// Youtube Slider Owl Carousel Init

		$('.youtube_slider_parent.owl-carousel').owlCarousel({
		    loop:false,
		    margin: 10,
		    nav: true,
		    dots: false,
		    autoplay:true,
		    autoplayTimeout: 10000,
		    autoplayHoverPause:true,
		    navText : ["<i class='fa fa-chevron-left'></i>","<i class='fa fa-chevron-right'></i>"],
		    responsiveClass:true,
 			responsive:{
 				0:{
 			        items:1
 			    },
 			    300:{
 			        items:2
 			    },
 			    600:{
 			        items:3
 			    },
 			    800:{
 			        items:4
 			    },
 			    1000:{
 			        items:5
 			    }
 			}
		})

	
	});

</script>

 
<?php

get_footer();
 
