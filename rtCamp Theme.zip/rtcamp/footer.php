<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package rtcamp
 */

?>

	</div><!-- #content -->

	<footer id="colophon" class="site-footer">

		<div class="container">	<!-- Container -->

			<div class="divider_20"></div>
			
			<div class="row">	<!-- Row -->

				<div class="col-xs-6 col-sm-4">	<!-- Col -->

					<?php 	// Footer Widget Area 1
 
					if ( is_active_sidebar( 'rtcamp-footer-area-1' ) ) :

						echo '<div class="rtcamp_custom_widget_area widget-area" role="complementary">' ;
					    
					    	dynamic_sidebar( 'rtcamp-footer-area-1' ); 

					    echo '</div>' ;
					     
					endif; 

					?>	<!-- Footer Widget Area 1 -->


				</div>	<!-- Col -->


				<div class="col-xs-6 col-sm-4">	<!-- Col -->
					
					<?php 	// Footer Widget Area 2
 
					if ( is_active_sidebar( 'rtcamp-footer-area-2' ) ) :

						echo '<div class="rtcamp_custom_widget_area widget-area" role="complementary">' ;
					    
					    	dynamic_sidebar( 'rtcamp-footer-area-2' ); 

					    echo '</div>' ;
					     
					endif; 

					?>	<!-- Footer Widget Area 2 -->

				</div>	<!-- Col -->


				<div class="col-xs-12 col-sm-4 footer_third_col">	<!-- Col -->

					<?php 	// Footer Widget Area 3
 
					if ( is_active_sidebar( 'rtcamp-footer-area-3' ) ) :

						echo '<div class="rtcamp_custom_widget_area widget-area" role="complementary">' ;
					    
					    	dynamic_sidebar( 'rtcamp-footer-area-3' ); 

					    echo '</div>' ;
					     
					endif; 

					?>	<!-- Footer Widget Area 3 -->
					

				</div>	<!-- Col -->

				
			</div>	<!-- Row -->

			<div class="divider_20"></div>


		</div>	<!-- Container -->

		<div class="container-fluid disclaimer_container">	<!-- Container Fluid -->
			
			<div class="row">

				<div class="col-12">

					<div class="divider_10"></div>
					
					<p class="footer_disclaimer"><b>Disclaimer :</b> At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident. Similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga.</p>

				</div>
				
			</div>

		</div>	<!-- Container Fluid -->

	</footer><!-- #colophon -->
</div><!-- #page -->

<?php wp_footer(); ?>
 

</body>
</html>
