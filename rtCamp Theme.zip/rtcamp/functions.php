<?php
/**
 * rtcamp functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package rtcamp
 */

if ( ! function_exists( 'rtcamp_setup' ) ) :
	/**
	 * Sets up theme defaults and registers support for various WordPress features.
	 *
	 * Note that this function is hooked into the after_setup_theme hook, which
	 * runs before the init hook. The init hook is too late for some features, such
	 * as indicating support for post thumbnails.
	 */
	function rtcamp_setup() {
		/*
		 * Make theme available for translation.
		 * Translations can be filed in the /languages/ directory.
		 * If you're building a theme based on rtcamp, use a find and replace
		 * to change 'rtcamp' to the name of your theme in all the template files.
		 */
		load_theme_textdomain( 'rtcamp', get_template_directory() . '/languages' );

		// Add default posts and comments RSS feed links to head.
		add_theme_support( 'automatic-feed-links' );

		/*
		 * Let WordPress manage the document title.
		 * By adding theme support, we declare that this theme does not use a
		 * hard-coded <title> tag in the document head, and expect WordPress to
		 * provide it for us.
		 */
		add_theme_support( 'title-tag' );

		/*
		 * Enable support for Post Thumbnails on posts and pages.
		 *
		 * @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
		 */
		add_theme_support( 'post-thumbnails' );

		// This theme uses wp_nav_menu() in one location.
		register_nav_menus( array(
			'menu-1' => esc_html__( 'Primary', 'rtcamp' ),
		) );

		/*
		 * Switch default core markup for search form, comment form, and comments
		 * to output valid HTML5.
		 */
		add_theme_support( 'html5', array(
			'search-form',
			'comment-form',
			'comment-list',
			'gallery',
			'caption',
		) );

		// Set up the WordPress core custom background feature.
		add_theme_support( 'custom-background', apply_filters( 'rtcamp_custom_background_args', array(
			'default-color' => 'ffffff',
			'default-image' => '',
		) ) );

		// Add theme support for selective refresh for widgets.
		add_theme_support( 'customize-selective-refresh-widgets' );

		/**
		 * Add support for core custom logo.
		 *
		 * @link https://codex.wordpress.org/Theme_Logo
		 */
		add_theme_support( 'custom-logo', array(
			'height'      => 250,
			'width'       => 250,
			'flex-width'  => true,
			'flex-height' => true,
		) );
	}
endif;
add_action( 'after_setup_theme', 'rtcamp_setup' );

/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 */
function rtcamp_content_width() {
	// This variable is intended to be overruled from themes.
	// Open WPCS issue: {@link https://github.com/WordPress-Coding-Standards/WordPress-Coding-Standards/issues/1043}.
	// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound
	$GLOBALS['content_width'] = apply_filters( 'rtcamp_content_width', 640 );
}
add_action( 'after_setup_theme', 'rtcamp_content_width', 0 );

/**
 * Register widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */


/**
 * Enqueue scripts and styles.
 */
function rtcamp_scripts() {
	wp_enqueue_style( 'rtcamp-style', get_stylesheet_uri() );

	wp_enqueue_script( 'rtcamp-navigation', get_template_directory_uri() . '/js/navigation.js', array(), '20151215', true );

	wp_enqueue_script( 'rtcamp-skip-link-focus-fix', get_template_directory_uri() . '/js/skip-link-focus-fix.js', array(), '20151215', true );

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'rtcamp_scripts' );

/**
 * Implement the Custom Header feature.
 */
require get_template_directory() . '/inc/custom-header.php';

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * Functions which enhance the theme by hooking into WordPress.
 */
require get_template_directory() . '/inc/template-functions.php';

/**
 * Customizer additions.
 */
require get_template_directory() . '/inc/customizer.php';

/**
 * Load Jetpack compatibility file.
 */
if ( defined( 'JETPACK__VERSION' ) ) {
	require get_template_directory() . '/inc/jetpack.php';
}






// Add Jquery

function enqueue_jquery_from_cdn() {

    wp_deregister_script( 'jquery' );

    wp_enqueue_script( 'jquery', '//ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js', '', '1.12.4' );
}

add_action( 'wp_enqueue_scripts', 'enqueue_jquery_from_cdn' );




// Enqueue custom js for Admin use

function my_admin_custom_js() {
        wp_register_script( 'custom_wp_admin_js', get_stylesheet_directory_uri() . '/lib/custom-js/admin_js.js', false, '1.0.0' );
        wp_enqueue_script( 'custom_wp_admin_js' );
}

add_action( 'admin_enqueue_scripts', 'my_admin_custom_js' );



// Enqueue custom js for normal use

function my_custom_js() {

	wp_register_script( 'custom-js', get_template_directory_uri() . '/lib/custom-js/custom_js.js' );
	wp_enqueue_script( 'custom-js' );

}

add_action( 'wp_enqueue_scripts', 'my_custom_js' );






//	Remove WordPress Admin Bar for logged in users

add_filter('show_admin_bar', '__return_false');



// Add Secondary meny to WordPress Header

function register_secondary_cusmenu() {

  register_nav_menu('new-menu',__( 'Secondary Menu' ));

}

add_action( 'init', 'register_secondary_cusmenu' );




// Theme Options Page

function register_acf_options_pages() {

    // Check function exists.
    if( !function_exists('acf_add_options_page') )
        return;

    // register options page.
    $option_page = acf_add_options_page(array(
        'page_title'    => __('Theme Options'),
        'menu_title'    => __('Theme Options'),
        'menu_slug'     => 'theme-options',
        'capability'    => 'edit_posts',
        'redirect'      => false,
        'update_button' => __('Update Theme Options', 'acf'),
        'updated_message' => __("Theme Options Updated", 'acf'),
        'position' => '20.3',
        'icon_url' => 'dashicons-dashboard',
    ));
}

// Hook into acf initialization.
add_action('acf/init', 'register_acf_options_pages');







// Get the first image from post

function grab_firsty_img() {

  global $post, $posts;
  $first_img = '';
  ob_start();
  ob_end_clean();
  $output = preg_match_all('/<img.+?src=[\'"]([^\'"]+)[\'"].*?>/i', $post->post_content, $matches);
  $first_img = $matches[1][0];

  if( empty($first_img) ) {
    $first_img = "empty";
  }

  return $first_img;

}



// Widgetized Sidebar Area

function rtcamp_customwidget_area() {
 
    register_sidebar( array(
        'name'          => 'rtCamp Homepage Sidebar',
        'id'            => 'rtcamp-homepage-sidebar',
        'before_widget' => '<div class="rtcamp-widget">',
        'after_widget'  => '</div>',
        'before_title'  => '<h2 class="rtcamp-title">',
        'after_title'   => '</h2>',
    ) );
 
}

add_action( 'widgets_init', 'rtcamp_customwidget_area' );




// Widgetized Footer Area 1

function rtcamp_footer_widget_area_1() {
 
    register_sidebar( array(
        'name'          => 'Footer Area 1',
        'id'            => 'rtcamp-footer-area-1',
        'before_widget' => '<div class="rtcamp-widget">',
        'after_widget'  => '</div>',
        'before_title'  => '<h3 class="footer_widget_title">',
        'after_title'   => '</h3><div class="small_hruler"></div>',
    ) );
 
}

add_action( 'widgets_init', 'rtcamp_footer_widget_area_1' );


			



// Widgetized Footer Area 2

function rtcamp_footer_widget_area_2() {
 
    register_sidebar( array(
        'name'          => 'Footer Area 2',
        'id'            => 'rtcamp-footer-area-2',
        'before_widget' => '<div class="rtcamp-widget">',
        'after_widget'  => '</div>',
        'before_title'  => '<h3 class="footer_widget_title">',
        'after_title'   => '</h3><div class="small_hruler"></div>',
    ) );
 
}

add_action( 'widgets_init', 'rtcamp_footer_widget_area_2' );




// Widgetized Footer Area 3

function rtcamp_footer_widget_area_3() {
 
    register_sidebar( array(
        'name'          => 'Footer Area 3',
        'id'            => 'rtcamp-footer-area-3',
        'before_widget' => '<div class="rtcamp-widget">',
        'after_widget'  => '</div>',
        'before_title'  => '<h3 class="footer_widget_title">',
        'after_title'   => '</h3><div class="small_hruler"></div>',
    ) );
 
}

add_action( 'widgets_init', 'rtcamp_footer_widget_area_3' );

 





// News Sidebar Widget


class News_posts_widget extends WP_Widget {

	
	public function __construct() {
		$widget_ops = array( 
			'classname' => 'news_posts_widget',
			'description' => 'This widget displays all posts from the "News" category with a dynamic navigation',
		);
		parent::__construct( 'news_posts_widget', 'rtCamp News Posts', $widget_ops );
	}

	
	public function widget( $args, $instance ) {

		echo $args['before_widget'];
		
		if ( ! empty( $instance['title'] ) ) {
			echo $args['before_title'] . apply_filters( 'widget_title', $instance['title'] ) . $args['after_title'];
		}


		// Sticky post query


		$sticky_args = array(
							'posts_per_page' => 1,
							'post__in' => get_option( 'sticky_posts' ),
							'ignore_sticky_posts' => 1,
							'orderby' => 'rand',
    						'order' => 'DESC',
						) ;

		$sticky_query = new WP_Query( $sticky_args );


		echo '<div class="hp_news_stickypost_parent">' ;	// <!-- Sticky Post Item -->

		while ( $sticky_query->have_posts() ) : 

			$sticky_query->the_post(); 

			?>
							
			<a href="<?php the_permalink() ; ?>" class="hp_news_stickypost_imgdiv">
				<img src="<?php echo get_the_post_thumbnail_url(get_the_ID(),'thumbnail') ; ?>">
			</a>

			<div class="hp_news_stickypost_info_div">
				<a href="<?php the_permalink() ; ?>" class="hp_news_stickypost_title"> <?php the_title(); ?> </a>
				<span class="hp_news_stickypost_date"> <?php echo get_the_date('F j, Y'); ?> </span>
			</div>
			

			<div class="clearfix"></div>	

			<?php 

		endwhile;

		echo '</div>' ; // <!-- Sticky Post Item -->

		wp_reset_postdata(); 	// // Sticky post query




		// news posts query
		?>

		<div class="news_sidebar_widget hp_news_recent_posts_parent">	<!-- Recent posts parent -->

			<script type="text/javascript">
				
				fetch_widget_news_posts() ; // Populate news posts

			</script>

		</div>	<!-- Recent posts parent -->

		<div class="hruler"></div>

		<?php

		echo $args['after_widget'];
	
	}

	
	public function form( $instance ) {

		$title = ! empty( $instance['title'] ) ? $instance['title'] : esc_html__( 'News', 'text_domain' );

		?>

		<div style="height: 20px;"></div>

		<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_attr_e( 'Title:', 'text_domain' ); ?></label>

		<div style="height: 5px;"></div>
		
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>">

		<div style="height: 20px;"></div>

		<?php
		
	}

	
	public function update( $new_instance, $old_instance ) {
	
		$instance = array();
		$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';

		return $instance;
	}

}

// register News_posts_widget

add_action( 'widgets_init', function(){
	register_widget( 'News_posts_widget' );
});











// Weather City Widget


class city_weather_posts_widget extends WP_Widget {

	
	public function __construct() {
		$widget_ops = array( 
			'classname' => 'city_weather_posts_widget',
			'description' => 'This widget displays the weather information of a City you choose',
		);
		parent::__construct( 'city_weather_posts_widget', 'rtCamp Weather', $widget_ops );
	}

	
	public function widget( $args, $instance ) {

		echo $args['before_widget'];
		 

		if ( ! empty( $instance['city_id'] ) ) {	// If has City ID


			

			$cityId = $instance['city_id'] ;

			$apiKey = "868e23443340c75fcbab1e45c5570123";

			$googleApiUrl = "https://api.openweathermap.org/data/2.5/forecast?id=" . $cityId . "&lang=en&units=metric&APPID=" . $apiKey . "&cnt=24" ;
			
			$ch = curl_init();
			
			curl_setopt($ch, CURLOPT_HEADER, 0);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
			curl_setopt($ch, CURLOPT_URL, $googleApiUrl);
			curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
			curl_setopt($ch, CURLOPT_VERBOSE, 0);
			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
			$response = curl_exec($ch);
			
			curl_close($ch);
			$data = json_decode($response);

			if ( $data->cod == '404' ||  $data->cod == '400' ) {	// Break function if city ID is invalid

				echo '<span class="weather_widget_error_msg">The City ID you entered seems to be incorrect. Please visit <a href="https://openweathermap.org/find?q=" target="_blank">OpenWeatherMap.org</a> to find the correct City ID</span>' ;

				echo '<div class="hruler"></div>' ;

				return false ;

			}	// Break function if city ID is invalid

			?>


			<?php

			if ( ! empty( $instance['title'] ) ) {	// echo widget title
				echo $args['before_title'] . apply_filters( 'widget_title', $instance['title'] ) . '  -  ' . $data->city->name . ' Forecast' . $args['after_title'];
			}	// echo widget title

			?>


			<div class="weather_widget_div"> <!-- Weather Widget -->
				
				<div class="weather_single_daydiv">	<!-- Single Item -->

					<?php $datey = date_create( $data->list[5]->dt_txt ) ; ?>

					<p class="weather_single_day_txt"> <?php echo date_format( $datey ,"l") ; ?> </p>

					<?php $icon_src = get_stylesheet_directory_uri() . '/lib/weather-icons/' .  $data->list[5]->weather[0]->icon . '.png' ; ?>

					<img class="weather_single_day_img" src="<?php echo $icon_src ; ?>">

					<span class="weather_single_day_stat"> <?php echo $data->list[5]->weather[0]->description ; ?> </span>
					<span class="weather_single_day_temp"> <?php echo $data->list[5]->main->temp ; ?> °C</span>
					
				</div>	<!-- Single Item -->


				<div class="weather_single_daydiv">	<!-- Single Item -->

					<?php $datey_2 = date_create( $data->list[13]->dt_txt ) ;  ?>

					<p class="weather_single_day_txt"> <?php echo date_format( $datey_2,"l") ; ?> </p>

					<?php $icon_src_2 = get_stylesheet_directory_uri() . '/lib/weather-icons/' .  $data->list[5]->weather[0]->icon . '.png' ; ?>

					<img class="weather_single_day_img" src="<?php echo $icon_src_2 ; ?>">


					<span class="weather_single_day_stat"> <?php echo $data->list[13]->weather[0]->description ; ?> </span>
					<span class="weather_single_day_temp"> <?php echo $data->list[13]->main->temp ; ?> °C</span>
					
				</div>	<!-- Single Item -->



				<div class="weather_single_daydiv">	<!-- Single Item -->

					<?php $datey_3 = date_create( $data->list[21]->dt_txt ) ;  ?>

					<p class="weather_single_day_txt"> <?php echo date_format( $datey_3,"l") ; ?> </p>

					<?php $icon_src_3 = get_stylesheet_directory_uri() . '/lib/weather-icons/' .  $data->list[5]->weather[0]->icon . '.png' ; ?>

					<img class="weather_single_day_img" src="<?php echo $icon_src_3 ; ?>">

					<span class="weather_single_day_stat"> <?php echo $data->list[21]->weather[0]->description ; ?> </span>
					<span class="weather_single_day_temp"> <?php echo $data->list[21]->main->temp ; ?> °C</span>
					
				</div>	<!-- Single Item -->
 

				<div class="clearfix"></div>

			</div>	<!-- Weather Widget -->

			<div class="hruler"></div>

			<?php

		}		// If has City ID


		// Front-end Codes



		wp_reset_postdata(); 	// news posts query



		echo $args['after_widget'];
	
	}

	
	public function form( $instance ) {

		$title = ! empty( $instance['title'] ) ? $instance['title'] : esc_html__( 'Weather', 'text_domain' );
		$city_id = ! empty( $instance['city_id'] ) ? $instance['city_id'] : esc_html__( '', 'text_domain' );

		?>

		<div style="height: 20px;"></div>

		<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_attr_e( 'Title:', 'text_domain' ); ?></label> 

		<div style="height: 5px;"></div>
		
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>">

		<div style="height: 20px;"></div>



		<label for="<?php echo esc_attr( $this->get_field_id( 'city_id' ) ); ?>"><?php esc_attr_e( 'City ID:', 'text_domain' ); ?></label> 

		<div style="height: 5px;"></div>
		
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'city_id' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'city_id' ) ); ?>" type="text" value="<?php echo esc_attr( $city_id ); ?>" placeholder="524901">

		<div style="height: 5px;"></div>

		<h3>How to find the city ID?</h3>

		<ol style="margin: 0 0 0 15px; ">
			<li>Go to <a href="https://www.openweathermap.org/">www.openweathermap.org</a>.</li>
			<div style="height: 10px;"></div>
			<li>Type the city or town name into the Search field and click the Search button.</li>
			<div style="height: 10px;"></div>
			<li>Locate the city in the search results, and click on its name.</li>
			<div style="height: 10px;"></div>
			<li>The City ID can be found in your browser’s address bar (see screenshot below).</li>
			<div style="height: 10px;"></div>
			<li>Copy this number to your clipboard or write it down.</li>
			<div style="height: 10px;"></div>
		</ol>

		<img src="http://davincidesigns.site/rtcamp/wp-content/uploads/2019/11/city_id-e1572972932545.png" style=" display: block; width: 100%; border: 1px solid #e5e5e5; border-radius: 3px; overflow: hidden; ">
		
		<div style="height: 20px;"></div>

		<?php
		
	}

	
	public function update( $new_instance, $old_instance ) {
	
		$instance = array();
		$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';

		$instance['city_id'] = ( ! empty( $new_instance['city_id'] ) ) ? strip_tags( $new_instance['city_id'] ) : '';

		return $instance;
	}

}

// register city_weather_posts_widget

add_action( 'widgets_init', function(){
	register_widget( 'city_weather_posts_widget' );
});










// Any City DateTime Widget


class anycity_datetime_widget extends WP_Widget {

	
	public function __construct() {
		$widget_ops = array( 
			'classname' => 'anycity_datetime_widget',
			'description' => 'This widget displays the Date & Time of any City you choose',
		);
		parent::__construct( 'anycity_datetime_widget', 'rtCamp DateTime Widget', $widget_ops );
	}

	
	public function widget( $args, $instance ) {

		echo $args['before_widget'];
		 

		if ( ! empty( $instance['city_name'] ) ) {	// If has City Name

			$cityNamer = $instance['city_name'] ;

			if ( ! empty( $instance['title'] ) ) {	// echo widget title
				echo $args['before_title'] . apply_filters( 'widget_title', $instance['title'] ) . '  -  ' . $cityNamer . $args['after_title'];
			}	// echo widget title



			$address = $cityNamer ;
						 
			$api_url = "https://maps.googleapis.com/maps/api/geocode/json?address={$address}&key=AIzaSyDBDSDw19iYcE3LEBbmScok9xGFV0RVMrE";
			
			$resp_json = file_get_contents($api_url);
			
			$resp = json_decode($resp_json, true);
			
			if( $resp['status']=='OK' ) {	// If city is valid from Geocoding API response
			     
			    $lati = $resp['results'][0]['geometry']['location']['lat'] ;
			    $longi = $resp['results'][0]['geometry']['location']['lng'] ;

			    $timezone_api_url = "https://maps.googleapis.com/maps/api/timezone/json?location=" . $lati . ',' . $longi . "&timestamp=1393575206&sensor=false&key=AIzaSyDBDSDw19iYcE3LEBbmScok9xGFV0RVMrE";
				
				$json_timezone = file_get_contents($timezone_api_url);

				$timzone_response = json_decode($json_timezone, true);

				if ( $timzone_response['status'] == 'OK' ) {	// If timezone is valid from TimeZone API
					
					$timezone_id = $timzone_response['timeZoneId'] ;

					$now_date = new DateTime("now", new DateTimeZone( $timezone_id ) );
					$curr_date = $now_date->format('l, j F');
					$curr_time = $now_date->format('H:i:s');

					?>

					<span class="hp_news_date_texty"> <?php echo $curr_date ; ?> </span>

					<span class="hp_news_date_timey"> <?php echo $curr_time ; ?> </span>

					<div class="hruler"></div>

					<?php

				}	// If timezone is valid from TimeZone API

				else {	// If timezone not valid from TimeZone API
					
					echo '<span class="weather_widget_error_msg">The City name you entered seems to be incorrect. Please check again to see if the city name is spelled correctly</span>' ;

					echo '<div class="hruler"></div>' ;

				}	// If timezone not valid from TimeZone API
				
			     
			}	// If city is valid from Geocoding API response


			else {	// If city is not valid

				echo '<span class="weather_widget_error_msg">The City name you entered seems to be incorrect. Please check again to see if the city name is spelled correctly</span>' ;

				echo '<div class="hruler"></div>' ;

			}	// If city is not valid
			

		}		// If has City Name


		echo $args['after_widget'];
	
	}

	
	public function form( $instance ) {

		$title = ! empty( $instance['title'] ) ? $instance['title'] : esc_html__( 'Date & Time', 'text_domain' );
		$city_name = ! empty( $instance['city_name'] ) ? $instance['city_name'] : esc_html__( '', 'text_domain' );

		?>

		<div style="height: 20px;"></div>

		<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_attr_e( 'Title:', 'text_domain' ); ?></label> 

		<div style="height: 5px;"></div>
		
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>">

		<div style="height: 20px;"></div>



		<label for="<?php echo esc_attr( $this->get_field_id( 'city_name' ) ); ?>"><?php esc_attr_e( 'City Name:', 'text_domain' ); ?></label> 

		<div style="height: 5px;"></div>
		
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'city_name' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'city_name' ) ); ?>" type="text" value="<?php echo esc_attr( $city_name ); ?>" placeholder="London">
		
		<div style="height: 20px;"></div>

		<?php
		
	}

	
	public function update( $new_instance, $old_instance ) {
	
		$instance = array();
		$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';

		$instance['city_name'] = ( ! empty( $new_instance['city_name'] ) ) ? strip_tags( $new_instance['city_name'] ) : '';

		return $instance;
	}

}


// register anycity_datetime_widget

add_action( 'widgets_init', function(){
	register_widget( 'anycity_datetime_widget' );
});














// Footer Pages Widget


class footer_pages_widget extends WP_Widget {

	
	public function __construct() {
		$widget_ops = array( 
			'classname' => 'footer_pages_widget',
			'description' => 'This widget displays any 5 pages you choose',
		);
		parent::__construct( 'footer_pages_widget', 'rtCamp Footer Pages', $widget_ops );
	}

	
	public function widget( $args, $instance ) {

		echo $args['before_widget'];


		if( ! empty( $instance['selected_posts'] ) && is_array( $instance['selected_posts'] ) ){ 	// If selected posts

			$selected_posts = get_posts( array( 'post__in' => $instance['selected_posts'] ) );


			if ( ! empty( $instance['title'] ) ) {	// echo widget title
				echo $args['before_title'] . apply_filters( 'widget_title', $instance['title'] ) . $args['after_title'];
			}	// echo widget title

			?>

			
			<div class="hp_news_recent_posts_parent">	<!-- Footer Links -->

			<?php

			foreach ( $selected_posts as $post ) { 
				?>

				<li class="hp_news_recent_posts_li footer_lister">
					<a href=" <?php echo get_permalink( $post->ID ); ?> ">
						<i class="fas fa-chevron-right"></i> <i class="fas fa-chevron-right"></i>
					 	<span> <?php echo $post->post_title; ?> </span>
					</a>
				</li> 
				
				<?php 
			} 

			echo '</div>' ; //	<!-- Footer Links -->
			
		}

		else{
			echo esc_html__( 'No posts selected to display!', 'text_domain' );	
		}	// If selected posts
		 
 


		echo $args['after_widget'];
	
	}

	
	public function form( $instance ) {

		$title = ! empty( $instance['title'] ) ? $instance['title'] : esc_html__( 'Pages', 'text_domain' );
		$selected_posts = ! empty( $instance['selected_posts'] ) ? $instance['selected_posts'] : array();

		?>

		<div style="height: 20px;"></div>

		<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_attr_e( 'Title:', 'text_domain' ); ?></label> 

		<div style="height: 5px;"></div>
		
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>">

		<div style="height: 20px;"></div>

		<label for="<?php echo esc_attr( $this->get_field_id( 'selected_posts' ) ); ?>"><?php esc_attr_e( 'Select any 5 Pages:', 'text_domain' ); ?></label> 

		<div style="height: 10px;"></div>

		<?php
		
		$posts = get_posts( array( 
					'posts_per_page' => 20,
					'offset' => 0,
					'post_status' => 'publish',
 					'order' => 'DESC',
 					'orderby' => 'date', 
				) );

		?>

		<div style="overflow: hidden; border: 1px solid #e5e5e5; padding: 10px 7px;">

		<ul class="footer_pages_widget_checkbox_parent" style=" max-height: 260px; overflow-y: auto; padding: 0; margin: 0; ">

		<?php 

		foreach ( $posts as $post ) { 

		?>

			<li>

				<input type="checkbox" name="<?php echo esc_attr( $this->get_field_name( 'selected_posts' ) ); ?>[]" value="<?php echo $post->ID; ?>" <?php checked( ( in_array( $post->ID, $selected_posts ) ) ? $post->ID : '', $post->ID ); ?> /> <span style=" font-size: 11px; "> <?php echo get_the_title( $post->ID ); ?> </span>

			</li>

			<div style="height: 3px;"></div>

		<?php 

		} 

		?>

		</ul>

		</div>

		<div style="height: 20px;"></div>

		<?php
		
	}

	
	public function update( $new_instance, $old_instance ) {
	
		$instance = array();
		$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';

		$selected_posts = ( ! empty ( $new_instance['selected_posts'] ) ) ? (array) $new_instance['selected_posts'] : array();
		$instance['selected_posts'] = array_map( 'sanitize_text_field', $selected_posts );

		return $instance;
	}

}


// register footer_pages_widget

add_action( 'widgets_init', function(){
	register_widget( 'footer_pages_widget' );
});











// Footer Links Widget


class footer_links_widget extends WP_Widget {

	
	public function __construct() {
		$widget_ops = array( 
			'classname' => 'footer_links_widget',
			'description' => 'This widget displays links in the footer',
		);
		parent::__construct( 'footer_links_widget', 'rtCamp Footer Links', $widget_ops );
	}

	
	public function widget( $args, $instance ) {

		echo $args['before_widget'];


		if ( ! empty( $instance['title'] ) ) {	// echo widget title
			echo $args['before_title'] . apply_filters( 'widget_title', $instance['title'] ) . $args['after_title'];
		}	// echo widget title



		echo '<div class="hp_news_recent_posts_parent">' ;	// <!-- Footer Links -->


		if ( ! empty( $instance['linky_1'] ) ) {	// echo Linker 1
			
			?>

			<li class="hp_news_recent_posts_li footer_lister">
				<a href=" <?php echo $instance['linky_1'] ; ?> ">
					<i class="fas fa-chevron-right"></i> <i class="fas fa-chevron-right"></i>
				 	<span> <?php echo $instance['link_title_1'] ; ?> </span>
				</a>
			</li> 

			<?php

		}	// echo Linker 1



		if ( ! empty( $instance['linky_2'] ) ) {	// echo Linker 2
			
			?>

			<li class="hp_news_recent_posts_li footer_lister">
				<a href=" <?php echo $instance['linky_2'] ; ?> ">
					<i class="fas fa-chevron-right"></i> <i class="fas fa-chevron-right"></i>
				 	<span> <?php echo $instance['link_title_2'] ; ?> </span>
				</a>
			</li> 

			<?php

		}	// echo Linker 2



		if ( ! empty( $instance['linky_3'] ) ) {	// echo Linker 3
			
			?>

			<li class="hp_news_recent_posts_li footer_lister">
				<a href=" <?php echo $instance['linky_3'] ; ?> ">
					<i class="fas fa-chevron-right"></i> <i class="fas fa-chevron-right"></i>
				 	<span> <?php echo $instance['link_title_3'] ; ?> </span>
				</a>
			</li> 

			<?php

		}	// echo Linker 3



		if ( ! empty( $instance['linky_4'] ) ) {	// echo Linker 4
			
			?>

			<li class="hp_news_recent_posts_li footer_lister">
				<a href=" <?php echo $instance['linky_4'] ; ?> ">
					<i class="fas fa-chevron-right"></i> <i class="fas fa-chevron-right"></i>
				 	<span> <?php echo $instance['link_title_4'] ; ?> </span>
				</a>
			</li> 

			<?php

		}	// echo Linker 4



		if ( ! empty( $instance['linky_5'] ) ) {	// echo Linker 5
			
			?>

			<li class="hp_news_recent_posts_li footer_lister">
				<a href=" <?php echo $instance['linky_5'] ; ?> ">
					<i class="fas fa-chevron-right"></i> <i class="fas fa-chevron-right"></i>
				 	<span> <?php echo $instance['link_title_5'] ; ?> </span>
				</a>
			</li> 

			<?php

		}	// echo Linker 5


		echo '</div>' ;		//	Footer Links 



		echo $args['after_widget'];
	
	}

	
	public function form( $instance ) {

		$title = ! empty( $instance['title'] ) ? $instance['title'] : esc_html__( 'Important Links', 'text_domain' );

		$link_title_1 = ! empty( $instance['link_title_1'] ) ? $instance['link_title_1'] : esc_html__( '', 'text_domain' );
		$link_title_2 = ! empty( $instance['link_title_2'] ) ? $instance['link_title_2'] : esc_html__( '', 'text_domain' );
		$link_title_3 = ! empty( $instance['link_title_3'] ) ? $instance['link_title_3'] : esc_html__( '', 'text_domain' );
		$link_title_4 = ! empty( $instance['link_title_4'] ) ? $instance['link_title_4'] : esc_html__( '', 'text_domain' );
		$link_title_5 = ! empty( $instance['link_title_5'] ) ? $instance['link_title_5'] : esc_html__( '', 'text_domain' );

		$linky_1 = ! empty( $instance['linky_1'] ) ? $instance['linky_1'] : esc_html__( '', 'text_domain' );
		$linky_2 = ! empty( $instance['linky_2'] ) ? $instance['linky_2'] : esc_html__( '', 'text_domain' );
		$linky_3 = ! empty( $instance['linky_3'] ) ? $instance['linky_3'] : esc_html__( '', 'text_domain' );
		$linky_4 = ! empty( $instance['linky_4'] ) ? $instance['linky_4'] : esc_html__( '', 'text_domain' );
		$linky_5 = ! empty( $instance['linky_5'] ) ? $instance['linky_5'] : esc_html__( '', 'text_domain' );

		
		?>

		<div style="height: 20px;"></div>

		<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_attr_e( 'Title:', 'text_domain' ); ?></label> 

		<div style="height: 5px;"></div>
		
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>">

		<div style="height: 20px;"></div>

		
		<!-- Link item 1 -->

		<label for="<?php echo esc_attr( $this->get_field_id( 'link_title_1' ) ); ?>"><?php esc_attr_e( 'Link Title 1:', 'text_domain' ); ?></label> 

		<div style="height: 5px;"></div>
		
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'link_title_1' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'link_title_1' ) ); ?>" type="text" value="<?php echo esc_attr( $link_title_1 ); ?>" placeholder="rtCamp Website">

		<div style="height: 10px;"></div> 

		<label for="<?php echo esc_attr( $this->get_field_id( 'linky_1' ) ); ?>"><?php esc_attr_e( 'Link 1:', 'text_domain' ); ?></label> 

		<div style="height: 5px;"></div>
		
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'linky_1' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'linky_1' ) ); ?>" type="text" value="<?php echo esc_attr( $linky_1 ); ?>" placeholder="https://rtcamp.com/">

		<div style="border-bottom: 1px solid #e0e0e0;padding: 16px 0 0px;margin-bottom: 12px;"></div>

		<!-- Link item 1 -->




		<!-- Link item 2 -->

		<label for="<?php echo esc_attr( $this->get_field_id( 'link_title_2' ) ); ?>"><?php esc_attr_e( 'Link Title 2:', 'text_domain' ); ?></label> 

		<div style="height: 5px;"></div>
		
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'link_title_2' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'link_title_2' ) ); ?>" type="text" value="<?php echo esc_attr( $link_title_2 ); ?>" placeholder="Google Website">

		<div style="height: 10px;"></div> 

		<label for="<?php echo esc_attr( $this->get_field_id( 'linky_2' ) ); ?>"><?php esc_attr_e( 'Link 2:', 'text_domain' ); ?></label> 

		<div style="height: 5px;"></div>
		
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'linky_2' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'linky_2' ) ); ?>" type="text" value="<?php echo esc_attr( $linky_2 ); ?>" placeholder="Link - https://www.google.com">

		<div style="border-bottom: 1px solid #e0e0e0;padding: 16px 0 0px;margin-bottom: 12px;"></div>

		<!-- Link item 2 -->



		<!-- Link item 3 -->

		<label for="<?php echo esc_attr( $this->get_field_id( 'link_title_3' ) ); ?>"><?php esc_attr_e( 'Link Title 3:', 'text_domain' ); ?></label> 

		<div style="height: 5px;"></div>
		
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'link_title_3' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'link_title_3' ) ); ?>" type="text" value="<?php echo esc_attr( $link_title_3 ); ?>" placeholder="Google Website">

		<div style="height: 10px;"></div> 

		<label for="<?php echo esc_attr( $this->get_field_id( 'linky_3' ) ); ?>"><?php esc_attr_e( 'Link 3:', 'text_domain' ); ?></label> 

		<div style="height: 5px;"></div>
		
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'linky_3' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'linky_3' ) ); ?>" type="text" value="<?php echo esc_attr( $linky_3 ); ?>" placeholder="Link - https://www.google.com">

		<div style="border-bottom: 1px solid #e0e0e0;padding: 16px 0 0px;margin-bottom: 12px;"></div>

		<!-- Link item 3 -->




		<!-- Link item 4 -->

		<label for="<?php echo esc_attr( $this->get_field_id( 'link_title_4' ) ); ?>"><?php esc_attr_e( 'Link Title 4:', 'text_domain' ); ?></label> 

		<div style="height: 5px;"></div>
		
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'link_title_4' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'link_title_4' ) ); ?>" type="text" value="<?php echo esc_attr( $link_title_4 ); ?>" placeholder="Google Website">

		<div style="height: 10px;"></div> 

		<label for="<?php echo esc_attr( $this->get_field_id( 'linky_4' ) ); ?>"><?php esc_attr_e( 'Link 4:', 'text_domain' ); ?></label> 

		<div style="height: 5px;"></div>
		
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'linky_4' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'linky_4' ) ); ?>" type="text" value="<?php echo esc_attr( $linky_4 ); ?>" placeholder="Link - https://www.google.com">

		<div style="border-bottom: 1px solid #e0e0e0;padding: 16px 0 0px;margin-bottom: 12px;"></div>

		<!-- Link item 4 -->





		<!-- Link item 5 -->

		<label for="<?php echo esc_attr( $this->get_field_id( 'link_title_5' ) ); ?>"><?php esc_attr_e( 'Link Title 5:', 'text_domain' ); ?></label> 

		<div style="height: 5px;"></div>
		
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'link_title_5' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'link_title_5' ) ); ?>" type="text" value="<?php echo esc_attr( $link_title_5 ); ?>" placeholder="Google Website">

		<div style="height: 10px;"></div> 

		<label for="<?php echo esc_attr( $this->get_field_id( 'linky_5' ) ); ?>"><?php esc_attr_e( 'Link 5:', 'text_domain' ); ?></label> 

		<div style="height: 5px;"></div>
		
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'linky_5' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'linky_5' ) ); ?>" type="text" value="<?php echo esc_attr( $linky_5 ); ?>" placeholder="Link - https://www.google.com">

		<!-- Link item 5 -->



		<div style="height: 20px;"></div>

 
		<?php
		
	}

	
	public function update( $new_instance, $old_instance ) {
	
		$instance = array();
		$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';

		$instance['link_title_1'] = ( ! empty( $new_instance['link_title_1'] ) ) ? strip_tags( $new_instance['link_title_1'] ) : '';
		$instance['linky_1'] = ( ! empty( $new_instance['linky_1'] ) ) ? strip_tags( $new_instance['linky_1'] ) : '';

		$instance['link_title_2'] = ( ! empty( $new_instance['link_title_2'] ) ) ? strip_tags( $new_instance['link_title_2'] ) : '';
		$instance['linky_2'] = ( ! empty( $new_instance['linky_2'] ) ) ? strip_tags( $new_instance['linky_2'] ) : '';

		$instance['link_title_3'] = ( ! empty( $new_instance['link_title_3'] ) ) ? strip_tags( $new_instance['link_title_3'] ) : '';
		$instance['linky_3'] = ( ! empty( $new_instance['linky_3'] ) ) ? strip_tags( $new_instance['linky_3'] ) : '';

		$instance['link_title_4'] = ( ! empty( $new_instance['link_title_4'] ) ) ? strip_tags( $new_instance['link_title_4'] ) : '';
		$instance['linky_4'] = ( ! empty( $new_instance['linky_4'] ) ) ? strip_tags( $new_instance['linky_4'] ) : '';

		$instance['link_title_5'] = ( ! empty( $new_instance['link_title_5'] ) ) ? strip_tags( $new_instance['link_title_5'] ) : '';
		$instance['linky_5'] = ( ! empty( $new_instance['linky_5'] ) ) ? strip_tags( $new_instance['linky_5'] ) : '';

		return $instance;

	}

}


// register footer_links_widget

add_action( 'widgets_init', function(){
	register_widget( 'footer_links_widget' );
});








// Footer Custom Link Shortcode


function footer_link_shortcode( $atts, $content = null ) {

    $a = shortcode_atts( array(
        'url' => '',
        'title'  =>  ''
    ), $atts );

    return '<a href="' . esc_attr($a['url']) . '" class="footer_shortcody_linker">' . esc_attr($a['title']) . '</a>' ;

}

add_shortcode( 'rt-link', 'footer_link_shortcode' );


 



// Load Ajax

add_action('wp_head', 'myplugin_ajaxurl');

function myplugin_ajaxurl() {

   echo '<script type="text/javascript">
           var ajaxurl = "' . admin_url('admin-ajax.php') . '";
         </script>';
}



//  News Posts Ajax Search Codes start here

function news_posts_ajax_searcher() {

    if (isset($_REQUEST)) {

        $page = $_REQUEST['page'];

        $args = array(  
					'posts_per_page' => 5, 
					'cat' => 4, 
					'post_status' => 'publish', 
					'order' => 'DESC', 
					'orderby' => 'date',
					'ignore_sticky_posts' => true,
					'paged' => $page,
 				) ;


        $news_query = new WP_Query( $args ); 

        $max_number_of_pages = $news_query->max_num_pages;
        $posts_found = $news_query->found_posts;

 		// news posts


        if ( $news_query->have_posts() ) {

            while ($news_query->have_posts()) {

                $news_query->the_post();
                
         		?>
				
				<li class="hp_news_recent_posts_li">
					<a href="<?php the_permalink() ; ?>">
						<i class="fas fa-chevron-right"></i> <i class="fas fa-chevron-right"></i>
					 	<span> <?php the_title() ; ?> </span>
					</a>
				</li>

				<?php 
            
            } 

            ?>

            
            <div class="pagination hp_news_recent_posts_navbox">	<!-- Pagination Div -->
		
                <?php 

                $prevPage = ($page - 1) ?: 1; 

                if( $posts_found > 10 ) { 

                	?>

					<button class="hp_news_recent_posts_arrow page-button <?php echo ($page - 1) ? ' ' : 'disabled' ?>" type="button" value="<?php echo $prevPage ?>" onClick="get_previous_page(this.value)"> <i class="fas fa-chevron-left"></i> </button>


	                <?php
	                    
	                    if ($max_number_of_pages - $page) {
	                        $nextPage = $page + 1;
	                    } 

	                    else {
	                        $nextPage = $max_number_of_pages;
	                    }

	                ?>

	                <button class="hp_news_recent_posts_arrow page-button <?php echo ($max_number_of_pages - $page) ? ' ': 'disabled' ?>" type="button" value="<?php echo $nextPage ?>" onClick="get_next_page(this.value)"> <i class="fas fa-chevron-right"></i> </button>

                <?php 

            	} 

                ?>
                
            </div>	<!-- Pagination Div -->

            <a href="<?php echo get_category_link(4) ; ?>" class="hp_news_recent_posts_linkmore">More News</a>

            <div class="clearfix"></div>

        <?php } 

        else {
            echo 'No results found';
        }

        wp_reset_postdata();


        ?> 


		<?php

    }

    die();
}

add_action('wp_ajax_news_posts_ajax_searcher', 'news_posts_ajax_searcher');
add_action('wp_ajax_nopriv_news_posts_ajax_searcher', 'news_posts_ajax_searcher');




