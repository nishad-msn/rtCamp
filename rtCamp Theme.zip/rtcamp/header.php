<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package rtcamp
 */

?>

<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">

	<!-- Font Awesome -->
	
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.11.2/css/all.min.css" integrity="sha256-+N4/V/SbAFiW1MPBCXnfnP9QSN3+Keu+NlB+0ev/YKQ=" crossorigin="anonymous" />
	
	<!-- Font Awesome -->


	<!-- Bootstrap Grid Only -->
	
	<link rel="stylesheet" href="<?php echo get_stylesheet_directory_uri() . '/lib/bootstrap/bootstrap.min.css' ; ?>" crossorigin="anonymous" />
	
	<!-- Bootstrap Grid Only -->


	<!-- Owl Carousel -->

	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" integrity="sha256-UhQQ4fxEeABh4JrcmAJ1+16id/1dnlOEVCFOxDef9Lw=" crossorigin="anonymous" />

	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css" integrity="sha256-kksNxjDRxd/5+jGurZUJd1sdR2v+ClrCl3svESBaJqw=" crossorigin="anonymous" />
	

	<!-- Owl Carousel -->

	<!-- Thickbox -->

	<link rel="stylesheet" href="<?php echo get_stylesheet_directory_uri() . '/lib/thickbox/thickbox.css' ; ?>" type="text/css" media="screen" />

	<!-- Thickbox -->


	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>

	<!-- FB Page plugin code -->

	<div id="fb-root"></div>
	<script async defer crossorigin="anonymous" src="https://connect.facebook.net/en_GB/sdk.js#xfbml=1&version=v5.0"></script>

	<!-- FB Page plugin code -->
	

<div id="page" class="site">
	<a class="skip-link screen-reader-text" href="#content"><?php esc_html_e( 'Skip to content', 'rtcamp' ); ?></a>

	<header id="masthead" class="site-header">

		<div class="header_top_main_section">	<!-- header main section -->
			

			<div class="header_top_sec_menu_div"> <!-- Secondary Menu bar -->

				<?php wp_nav_menu( array( 'theme_location' => 'new-menu', 'container_class' => 'new_menu_class' ) ); ?>

			</div>	<!-- Secondary Menu bar -->


			<a href="<?php echo get_home_url(); ?>" class="header_top_logo_div">	<!-- Logo Div -->

				<?php

					if ( get_field('theme_logo_image' , 'option') ) {	// If has logo img
						echo '<img class="header_top_logo_img" src="' . get_field('theme_logo_image' , 'option') . '">' ;
					}	// If has logo img

					else {	// If no logo
						echo '<img class="header_top_logo_img" src="' . get_stylesheet_directory_uri() . '/lib/sitelogo.png' . '">' ;
					}	// If no logo

				?>

			</a>	<!-- Logo Div -->


			<div class="header_top_google_search_div">	<!-- Google Search Input -->
				<script async src="https://cse.google.com/cse.js?cx=010137157102893131620:zmkujszs6nn"></script>
				<div class="gcse-search"></div>
			</div>	<!-- Google Search Input -->

			<div class="clearfix"></div>

		</div>	<!-- header main section -->

		<nav id="site-navigation" class="main-navigation">
			<button class="menu-toggle" aria-controls="primary-menu" aria-expanded="false"><?php esc_html_e( 'Primary Menu', 'rtcamp' ); ?></button>
			<?php
			wp_nav_menu( array(
				'theme_location' => 'menu-1',
				'menu_id'        => 'primary-menu',
			) );
			?>
		</nav><!-- #site-navigation -->
	</header><!-- #masthead -->

	<div id="content" class="site-content">
